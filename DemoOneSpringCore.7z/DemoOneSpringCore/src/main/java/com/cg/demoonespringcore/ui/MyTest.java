package com.cg.demoonespringcore.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.demoonespringcore.dto.Item;
import com.cg.demoonespringcore.dto.Product;

public class MyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext app = new ClassPathXmlApplicationContext("spring.xml");
		
		Product p = (Product) app.getBean("prod");
/*		p.setId(1001);
		p.setName("tv");
		p.setPrice(45283.00);
		p.setDescription("Sony");*/
		//Item i = (Item) app.getBean("item");
		p.getAllData();
		
		//i.getData();
	}

}
