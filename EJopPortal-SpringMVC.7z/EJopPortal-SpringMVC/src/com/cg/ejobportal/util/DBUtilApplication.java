package com.cg.ejobportal.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobApplication;
import com.cg.ejobportal.dto.JobSeeker;

public class DBUtilApplication {

	public static List<JobApplication> applications = new ArrayList<JobApplication>();
	public static List<Job> appliedJobs = new ArrayList<Job>();
}
