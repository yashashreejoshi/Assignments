package com.cg.ejobportal.service;

import com.cg.ejobportal.dto.JobProvider;

public interface IJobProviderService {
	public JobProvider addProvider(JobProvider provider);
	public JobProvider searchByProviderId(int id);

}
