package com.cg.ejobportal.service;

import java.util.List;

import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobApplication;
import com.cg.ejobportal.dto.JobSeeker;

public interface IJobApplicationService {
	public List<JobApplication> applyJob(JobApplication application);
	

}
