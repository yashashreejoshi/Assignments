package com.cg.ejobportal.exception;

public class JobAppliedNotFoundException extends RuntimeException{

	public JobAppliedNotFoundException() {
		super();
	}
	
	public JobAppliedNotFoundException(String msg) {
		super(msg);
	}
}
