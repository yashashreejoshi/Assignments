package com.cg.ejobportal.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobApplication;
import com.cg.ejobportal.dto.JobSeeker;

import com.cg.ejobportal.util.DBUtilApplication;
import com.cg.ejobportal.util.DBUtilJob;
import com.cg.ejobportal.util.DBUtilSeeker;

/*This class is a implementation of IJobApplication repository interface.
 *
 *
 * Last Modified 14/05/2019  07.30 p.m.
 * Author: Yashashree Joshi
 */
@Repository("applicationDao")
public class IJobApplicationDaoImpl implements IJobApplicationDao {

	/*This method is a implementation of IJobApplication repository interface method.
	 * It includes saving of job application.
	 * 
	 * @param args JobApplication application. 
	 * @return List<JobApplication>.
	 * 
	 * Last Modified 14/05/2019  07.30 p.m.
	 * Author: Yashashree Joshi
	 */
	
	
	
	public List<JobApplication> save(JobApplication application) {
		DBUtilApplication.applications.add(application);
		return DBUtilApplication.applications;
	}

	
}
