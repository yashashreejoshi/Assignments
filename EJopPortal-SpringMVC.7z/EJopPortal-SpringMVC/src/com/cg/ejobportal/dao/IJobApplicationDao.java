package com.cg.ejobportal.dao;

import java.util.List;

import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobApplication;
import com.cg.ejobportal.dto.JobSeeker;

/*This method is used to save jobApplication.
 *
 * @param args JobApplication application. 
 * @return List<JobApplication>.
 * 
 * Last Modified 14/05/2019  07.30 p.m.
 * Author: Yashashree Joshi
 */
public interface IJobApplicationDao {
	public List<JobApplication> save(JobApplication application);
	
}
