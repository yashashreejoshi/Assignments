package com.cg.ejobportal.dao;

import com.cg.ejobportal.dto.JobProvider;

public interface IJobProviderDao {
	public JobProvider save(JobProvider provider);
	public JobProvider findById(int id);

}
