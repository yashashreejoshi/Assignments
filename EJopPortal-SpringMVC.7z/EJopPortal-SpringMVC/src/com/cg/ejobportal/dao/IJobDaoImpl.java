package com.cg.ejobportal.dao;

import java.nio.file.ProviderNotFoundException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.dto.JobApplication;
import com.cg.ejobportal.dto.JobProvider;
import com.cg.ejobportal.exception.JobAppliedNotFoundException;
import com.cg.ejobportal.exception.JobIdNotFoundException;
import com.cg.ejobportal.exception.JobNotFoundException;
import com.cg.ejobportal.util.DBUtilApplication;
import com.cg.ejobportal.util.DBUtilJob;
import com.cg.ejobportal.util.DBUtilProvider;

/*This class is a implementation of IJob repository interface.
 *
 * Last Modified 14/05/2019  07.30 p.m.
 * Author: Yashashree Joshi
 */
@Repository("jobDao")
public class IJobDaoImpl implements IJobDao {
	static final Logger logger = Logger.getLogger(IJobDaoImpl.class);
	/*This method is a implementation of IJobDao repository interface method.
	 * It includes saving of job application.
	 * 
	 * @param args Job job. 
	 * @return Job.
	 * 
	 * Last Modified 14/05/2019  07.30 p.m.
	 * Author: Yashashree Joshi
	 */
	public Job save(Job job) {
		BasicConfigurator.configure();
		DBUtilJob.jobs.add(job);
		logger.info("adding the job");
		return job;
	}

	/*This method is a implementation of IJobDao repository interface method.
	 * It includes searching of jobs by description.
	 * 
	 * @param args String description. 
	 * @return List<Job>.
	 * 
	 * Last Modified 14/05/2019  07.30 p.m.
	 * Author: Yashashree Joshi
	 */
	public List<Job> findByDescription(String description) {
		BasicConfigurator.configure();
		List<Job> storeJobs = new ArrayList<Job>();
		for(Job job:DBUtilJob.jobs) {
			if(job.getDescription().equals(description))
				storeJobs.add(job);	
		}
		logger.info("searching the jobs by description");
		return storeJobs;
	}

	/*This method is a implementation of IJobDao repository interface method.
	 * It includes searching of jobs by city.
	 * 
	 * @param args String city. 
	 * @return List<Job>.
	 * 
	 * Last Modified 14/05/2019  07.30 p.m.
	 * Author: Yashashree Joshi
	 */
	public List<Job> findByCity(String city) {
		BasicConfigurator.configure();
		List<Job> storeJobs = new ArrayList<Job>();
		for(Job job:DBUtilJob.jobs) {
			if(job.getCity().equals(city))
				storeJobs.add(job);	
		}
		if(storeJobs.isEmpty())
			throw new JobNotFoundException("Jobs you are searching are not available");
		logger.info("searching the jobs by city");
		return storeJobs;
	}
	
	/*This method is a implementation of IJobDao repository interface method.
	 	 * It includes searching of jobs by id.
	 * 
	 * @param args int id. 
	 * @return Job.
	 * 
	 * Last Modified 14/05/2019  07.30 p.m.
	 * Author: Yashashree Joshi
	 */
	public Job findById(int id)  {
		for(Job idSearch: DBUtilJob.jobs) {
			if(idSearch.getId()==id) {
				return idSearch;	
			}
		}
	return null;
	}

}
