package com.cg.ejobportal.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.cg.ejobportal.dto.JobProvider;
import com.cg.ejobportal.service.IJobProviderService;

@Controller
public class MyController {
	
	@Autowired
	IJobProviderService providerService;
	@GetMapping("login")
	//@RequestMapping(value="login", method=RequestMethod.GET)
	public String loginPage() {
		return "mylogin";
		
	}
	
	@PostMapping("checkLogin")
	public String doLogin(@RequestParam("uname") String user, @RequestParam("upass") String pass) {
		System.out.println("in check login....");
		
		if(user.equals("admin") && pass.equals("12345")) {
			return "mainmenu";
		}
		else {
			return "error";
		}
	}
	
	@GetMapping("add")
	public ModelAndView getAddProduct(@ModelAttribute("prov") JobProvider JobProvider) {
	
		return new ModelAndView("addProvider");
	}
	
	@PostMapping("addprovider")
	public ModelAndView addProduct(@ModelAttribute("prod") JobProvider provider) {
		System.out.println(provider);
		JobProvider product=providerService.addProvider(provider);
		return new ModelAndView("success", "key", product);
		//return null;//all the values is stored in key of product and passed to success.jsp
	}
}
