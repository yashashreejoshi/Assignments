package com.cg.ejobportal.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ejobportal.dao.IJobDao;
import com.cg.ejobportal.dao.IJobDaoImpl;
import com.cg.ejobportal.dto.Job;
import com.cg.ejobportal.exception.JobIdNotFoundException;
import com.cg.ejobportal.exception.JobNotFoundException;

@Service("jobService")
public class IJobServiceImpl implements IJobService{
	@Autowired
	IJobDao jobDao;
	
	public Job addJob(Job job) {
		return jobDao.save(job);
	}
	public List<Job> searchByJobDescription(String description) {
		List<Job> storeJobs = jobDao.findByDescription(description);
		if(storeJobs.isEmpty())
			throw new JobNotFoundException("Jobs you are searching are not available");
		return jobDao.findByDescription(description);
		
	}
	public List<Job> searchByJobCity(String city) {
		List<Job> storeJobs = jobDao.findByCity(city);
		if(storeJobs.isEmpty())
			throw new JobNotFoundException("Jobs you are searching are not available");
		return jobDao.findByCity(city);
	}
	public Job searchByJobId(int id) {
		Job job=jobDao.findById(id);
		if(job==null)
			throw new JobIdNotFoundException("job id not found");
		return job;
	}
}
