package com.cg.ejobportal.dao;

import java.nio.file.ProviderNotFoundException;

import org.springframework.stereotype.Repository;

import com.cg.ejobportal.dto.JobProvider;
import com.cg.ejobportal.util.DBUtilProvider;

@Repository("providerDao")
public class IJobProviderDaoImpl implements IJobProviderDao {
	
	public JobProvider save(JobProvider provider) {
		DBUtilProvider.providers.add(provider);
		return provider;
	}

	public JobProvider findById(int id) {
		for(JobProvider provide: DBUtilProvider.providers) {
			if(provide.getId()==id) {
				return provide;	
			}
			else {
				throw new ProviderNotFoundException("Id not found");
			}
		}
	return null;
	}
	

}
