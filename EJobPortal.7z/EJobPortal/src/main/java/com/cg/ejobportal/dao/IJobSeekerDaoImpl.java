package com.cg.ejobportal.dao;

import java.nio.file.ProviderNotFoundException;

import org.springframework.stereotype.Repository;

import com.cg.ejobportal.dto.JobProvider;
import com.cg.ejobportal.dto.JobSeeker;
import com.cg.ejobportal.exception.SeekerNotFoundException;
import com.cg.ejobportal.util.DBUtilProvider;
import com.cg.ejobportal.util.DBUtilSeeker;

@Repository("seekerDao")
public class IJobSeekerDaoImpl implements IJobSeekerDao{
	
	public JobSeeker save(JobSeeker seeker) {
		// TODO Auto-generated method stub
		DBUtilSeeker.seekers.add(seeker);
		return seeker;
	}

	public JobSeeker findById(int id) {
		for(JobSeeker seek: DBUtilSeeker.seekers) {
			if(seek.getId()==id) {
				return seek;	
			}
		
		}
	return null;
	}

}
