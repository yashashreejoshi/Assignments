package com.cg.ejobportal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ejobportal.dao.IJobProviderDao;
import com.cg.ejobportal.dao.IJobProviderDaoImpl;
import com.cg.ejobportal.dto.JobProvider;
import com.cg.ejobportal.exception.ProviderNotFoundException;

@Service("providerService")
public class IJobProviderServiceImpl implements IJobProviderService{
	@Autowired
	IJobProviderDao providerDao;
	
	public JobProvider addProvider(JobProvider provider) {
		// TODO Auto-generated method stub
		return providerDao.save(provider);
	}

	public JobProvider searchByProviderId(int id) {
		// TODO Auto-generated method stub
		JobProvider provider = providerDao.findById(id);
		if(provider==null)
			throw new ProviderNotFoundException("provider not found");
		return provider;
	}
	

}
