package com.cg.ejobportal.dto;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("jobapplication")
@Scope("prototype")
public class JobApplication {
	public JobApplication() {
		
	}
	
	public JobApplication(int id, Date date, JobSeeker seeker, Job job) {
		super();
		this.id = id;
		this.date = date;
		this.seeker = seeker;
		this.job = job;
	}
	
	private int id;
	private Date date;
	@Autowired
	private JobSeeker seeker;
	@Autowired
	private Job job;
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public JobSeeker getSeeker() {
		return seeker;
	}
	public void setSeeker(JobSeeker seeker) {
		this.seeker = seeker;
	}
	public Job getJob() {
		return job;
	}
	public void setJob(Job job) {
		this.job = job;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "JobApplication [id=" + id + ", date=" + date + ", seeker=" + seeker + ", job=" + job + "]";
	}

}
